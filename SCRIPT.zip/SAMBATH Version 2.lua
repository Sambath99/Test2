Date = "20201119"
date = os.date("%Y%m%d")
if date >= Date then
  print("▰▱▰▱▰▱▰▱▰▱▰▱▰")
  print("𝐒𝐜𝐫𝐢𝐩𝐭 ត្រូវបានផុតកំណត់")
  print("𝐒𝐜𝐫𝐢𝐩𝐭 𝐇𝐚𝐬 𝐄𝐱𝐩𝐢𝐫𝐞")
  print("𝐓𝐡𝐚𝐧𝐤 𝐅𝐨𝐫 𝐁𝐮𝐲𝐢𝐧𝐠 𝐌𝐲 𝐒𝐜𝐫𝐢𝐩𝐭")
  print("▰▱▰▱▰▱▰▱▰▱▰▱▰")
  os.exit()
end
gg.alert(" បទហាម \n 👉ហាមយកចែកគេ \n  👉ហាមDc \n 🙏អរគុណសម្រាប់ការទិញស្ក្រីបខ្ញុំលេង🙏")
gg.sleep(150)
gg.toast("▓░░░░░░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓░░░░░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓░░░░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓░░░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓░░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓░សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន░░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓░░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓░░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓░░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓░░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓▓░░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓▓▓░ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓▓▓▓ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓▓▓▓ ")
gg.sleep(150)
gg.toast("▓▓▓▓▓▓▓សៀង ម៉េងជ្រិន▓▓▓▓▓▓▓ ")
gg.sleep(150)
gg.setVisible(false)
gg.toast("□□□□□□□□□□5%")
gg.sleep(150)
gg.toast("■□□□□□□□□□10%")
gg.sleep(150)
gg.toast("■□□□□□□□□□15%")
gg.sleep(150)
gg.toast("■■□□□□□□□□20%")
gg.sleep(150)
gg.toast("■■□□□□□□□□25%")
gg.sleep(150)
gg.toast("■■■□□□□□□□30%")
gg.sleep(150)
gg.toast("■■■□□□□□□□35%")
gg.sleep(150)
gg.toast("■■■■□□□□□□40%")
gg.sleep(150)
gg.toast("■■■■□□□□□□45%")
gg.sleep(150)
gg.toast("■■■■■□□□□□50%")
gg.sleep(150)
gg.toast("■■■■■□□□□□55%")
gg.sleep(150)
gg.toast("■■■■■■□□□□60%")
gg.sleep(150)
gg.toast("■■■■■■□□□□65%")
gg.sleep(150)
gg.toast("■■■■■■■□□□70%")
gg.sleep(150)
gg.toast("■■■■■■■□□□75%")
gg.sleep(150)
gg.toast("■■■■■■■■□□80%")
gg.sleep(150)
gg.toast("■■■■■■■■□□85%")
gg.sleep(150)
gg.toast("■■■■■■■■■□90%")
gg.sleep(150)
gg.toast("■■■■■■■■■□95%")
gg.sleep(150)
gg.toast("■■■■■■■■■■100%")
gg.sleep(150)
gg.clearResults()
gg.alert("█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█\n W͎E͎L͎L͎C͎O͎M͎E͎ T͎O͎ M͎Y͎ S͎C͎R͎I͎P͎T͎ \n🙏 ❤សូមលេងដោយសប្បាយ❤🙏\n 《𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞 : 𝐒𝐚𝐦𝐳𝐳 𝐁𝐚𝐭𝐡𝐳𝐳》\n 《𝗙𝗔𝗖𝗘𝗕𝗢𝗢𝗞: 𝗠𝗘𝗡𝗚 𝗝𝗥𝗜𝗡》\n《𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠 : សៀង ម៉េងជ្រិន ( ABI2G7K1.22) ᵐⁱˢᵗᵉʳメvirusシ︎☂️ ")
Samzz = {
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁ដាក់មុនចូល꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎ ꧁ដាក់ក្នុងGame꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁សម្រាប់VIP꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁ពណ៌VIP☯︎꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"⏪❤🇪 🇽 🇮 🇹 ❤⏪"}
	Samzzk = 0
	Hack = 1
function main()
Samz = gg.choice(Samzz,Samzzk,"⭐Script By Sambath\n ⭐expire date next week⭐\n⭐Telegram:Sambath Hacker⭐ ")
if Samz == 1 then AM()end
if Samz == 2 then BM()end
if Samz == 3 then CM()end
if Samz == 4 then DM()end
if Samz == 5 then EXIT()end
if Samz == nil then KH()end

Hack = -1
end

function AM()
Amenu = gg.multiChoice({
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁កានុងទាញ 360⁰꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁កានុងទាញ 100%꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁បាញ់អរេ 100%꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁ចុះឆាតលឿន ꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	"╔क══⊱≪ •🇰🇭• ≫⊰══क╗\n    ❥︎꧁កាមេរា ឆ្ងាយ ꧂☯︎\n╚क══⊱≪ •🇰🇭• ≫⊰══क╝",
	},nil,os.date("⭐Made By Meng Jrin ⭐\n\n%d/%m/%Y/%H:%M:%S"))
	
	if Amenu == nil then main()
	else
	if Amenu[1] == true then A1()end
	if Amenu[2] == true then A2()end
	if Amenu[3] == true then A3()end
	if Amenu[4] == true then A4()end
	if Amenu[5] == true then A5()end
	if Amenu[6] == true then A6()end
	if Amenu[7] == true then A7()end
	end
	end
	
function BM()
Bmenu = gg.multiChoice({
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ដើរថ្លុះ= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ដើរថ្លុះ= បិត꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁អត់ស្មៅ = បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁អត់ស្មៅ = បិត꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ឃើញដានជើងបានឆ្ងាយ = បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁SCOPEខ្ពស់ = បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁រត់លឿនក្នុង Rank= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁កានុងទាញអត់ដាច់= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁កានុងអត់រេ 100% = បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	},nil,os.date("⭐Made By Meng Jrin ⭐\n\n%d/%m/%Y/%H:%M:%S"))
	
	if Bmenu == nil then main()
	else
	if Bmenu[1] == true then B1()end
	if Bmenu[2] == true then B2()end
	if Bmenu[3] == true then B3()end
	if Bmenu[4] == true then B4()end
	if Bmenu[5] == true then B5()end
	if Bmenu[6] == true then B6()end
	if Bmenu[7] == true then B7()end
	if Bmenu[8] == true then B8()end
	if Bmenu[9] == true then B9()end
	if Bmenu[10] == true then B10()end
	if Bmenu[11] == true then B11()end
	end
	end
	
function CM()
Cmenu = gg.multiChoice({
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁មានScopeស្រាប់= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁រត់លឿន ដូចរន្ទះ= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁រត់លឿន ដូចរន្ទះ= បិត꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ដើរលើមេឃ= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ដើរលើមេឃ= បិត꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ខ្លួនធំ= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ខ្លួនធំ= បិត꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁បាញ់លឿន= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁មើលធ្លុះ= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ក្បាលវែង= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁ក្រាប់ក្នុងដី= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	},nil,os.date("⭐Made By Meng Jrin ⭐\n\n%d/%m/%Y/%H:%M:%S"))
	
	if Cmenu == nil then main()
	else
	if Cmenu[1] == true then C1()end
	if Cmenu[2] == true then C2()end
	if Cmenu[3] == true then C3()end
	if Cmenu[4] == true then C4()end
	if Cmenu[5] == true then C5()end
	if Cmenu[6] == true then C6()end
	if Cmenu[7] == true then C7()end
	if Cmenu[8] == true then C8()end
	if Cmenu[9] == true then C9()end
	if Cmenu[10] == true then C10()end
	if Cmenu[11] == true then C11()end
	if Cmenu[12] == true then C12()end
	end
	end
	
function DM()
Dmenu = gg.multiChoice({
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁🔴ខ្លួនពណ៌ ក្រហម🔴= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁🟢ខ្លួនពណ៏ បៃតង🟢= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁🟡ខ្លួនពណ៌ លឿង🟡= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁មើលធ្លូះដី= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	"╔═━═━•⊱❤︎⊰•━═━═╗\n    ❥︎꧁💕បាញ់ចេញពណ៌ ផ្កាឈូក 💕= បើក꧂☯︎\n╚═━═━•⊱❤︎⊰•━═━═╝",
	},nil,os.date("⭐Made By Meng Jrin ⭐\n\n%d/%m/%Y/%H:%M:%S"))
	
	if Dmenu == nil then main()
	else
	if Dmenu[1] == true then D1()end
	if Dmenu[2] == true then D2()end
	if Dmenu[3] == true then D3()end
	if Dmenu[4] == true then D4()end
	if Dmenu[5] == true then D5()end
	if Dmenu[6] == true then D6()end
	end
	end
	
function KH()
  gg.toast("⚠️❤🇰🇭 I LOVE YOU🇰🇭❤⚠️")
  end
  
function A1()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.searchNumber("-90E::1E", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.refineNumber("-1", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(3)
gg.editAll("100", gg.TYPE_DOUBLE)
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("3.14", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.refineNumber("3.14", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(4)
gg.editAll("180", gg.TYPE_DOUBLE)
gg.toast("កានុងទាញ 360")
gg.clearResults()
end
function A2()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.searchNumber("6D;0.3E::21", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("0.3", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(4)
gg.editAll("1", gg.TYPE_DOUBLE)
gg.toast("កានុងទាញ 50%")
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.searchNumber("9,999,999.0;0.2;0.1;30.0;800.0;10.0;17D;1.0;2.0::512", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("0.2;0.1;30.0;800.0;10.0;1.0;2.0", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(10)
gg.editAll("0.00001;0.00001;-1;1801;999999999;999999999;999999999;999999999", gg.TYPE_DOUBLE)
gg.toast("AIM 100%")
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("999999", gg.TYPE_DOUBLE)
gg.refineNumber("999999", gg.TYPE_DOUBLE)
gg.getResults(5)
gg.editAll("1.0e303", gg.TYPE_DOUBLE)
gg.getResults(5)
gg.toast(" កានុងទាញ 100%")
gg.clearResults()
end
function A3()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("-1;1;-90::200", gg.TYPE_DOUBLE)
gg.searchNumber("-1", gg.TYPE_DOUBLE)
gg.getResults(12)
gg.editAll("1.132", gg.TYPE_DOUBLE)
gg.toast("បាញ់អត់រេ")
end
function A4()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("5.7397185e-41F;2,000D", 4)
gg.searchNumber("2,000", 4)
gg.getResults(2)
gg.editAll("60", 4)
gg.toast("ចុះឆ័ត្រយោងលឿន")
gg.clearResults()
end
function A5()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("27.0E;12.0;-39.0", gg.TYPE_DOUBLE)
gg.refineNumber("27", gg.TYPE_DOUBLE, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(3)
gg.editAll("35", gg.TYPE_DOUBLE)
gg.toast("កាមេរា ឆ្ងាយ")
gg.clearResults()
end
function B1()
gg.clearResults()
gg.setRanges(48)
gg.searchNumber("9.9999997e-10", 16)
gg.getResults(10)
gg.editAll("99999999", 16)
gg.toast(" ដើរថ្លុះ បើក ")
end
function B2()
gg.clearResults()
gg.setRanges(48)
gg.searchNumber("99999999", 16)
 gg.getResults(10)
gg.editAll("9.9999997e-10", 16)
gg.toast(" ដើរថ្លុះ បិត ")
end
function B3()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("7.17745073e-42F;1.40129846e-45F", gg.TYPE_FLOAT)
gg.refineNumber("7.17745073e-42", gg.TYPE_FLOAT)
gg.getResults(1)
gg.editAll("0", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("អត់ស្មៅ បើក")
end
function B4()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("0", gg.TYPE_FLOAT)
gg.refineNumber("0", gg.TYPE_FLOAT)
gg.getResults(1)
gg.editAll("7.17745073e-42", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("អត់ស្មៅ បិត")
end
function B5()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1,071,644,672D;1,048,238,066D;1E;1,069,128,089D;1,071,644,672D:330", gg.TYPE_DOUBLE)
gg.refineNumber("1", gg.TYPE_DOUBLE)
gg.getResults(8)
gg.editAll("8888", gg.TYPE_DOUBLE)
gg.toast("ឃើញដានជើងបានឆ្ងាយ បើក")
gg.setVisible(false)
gg.clearResults()
end
function B6()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("4.5E;19.4E", gg.TYPE_DOUBLE)
gg.searchNumber("19.4", gg.TYPE_DOUBLE)
gg.getResults(4)
gg.editAll("90", gg.TYPE_DOUBLE)
gg.toast("SCOPEខ្ពស់ បើក")
end
function B7()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1.1E;-2,000.0E", gg.TYPE_DOUBLE)
gg.searchNumber("1.1", gg.TYPE_DOUBLE)
gg.getResults(2)
gg.editAll("1.7", gg.TYPE_DOUBLE)
gg.toast("រត់លឿនក្នុង Rank បើក")
gg.clearResults()
end
function B8()
 gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("5.0E;0.2E;0.1E;0.5E;0.5E;0.05E:300", gg.TYPE_DOUBLE)
gg.refineNumber("0.1", gg.TYPE_DOUBLE)
gg.getResults(5)
gg.editAll("666666666", gg.TYPE_DOUBLE)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0.01E;1.5E;1.0E;1.0E;5.0E:200", gg.TYPE_DOUBLE)
gg.refineNumber("0.01", gg.TYPE_DOUBLE)
gg.getResults(2)
gg.editAll("-1.5", gg.TYPE_DOUBLE)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("2D;0.1E;5364095385Q;1.75F:45", gg.TYPE_DOUBLE)
gg.refineNumber("0.1", gg.TYPE_DOUBLE)
gg.getResults(20)
gg.editAll("77777", gg.TYPE_DOUBLE)
gg.toast("កានុងទាញអត់ដាច់ 100%")
gg.setVisible(false)
gg.clearResults()
end
function B9()
gg.alert("សូមដាក់កូដនេះក្នុងgameកុំដាក់ករាវGame")
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("-10E;1,000E;1E::305", gg.TYPE_DOUBLE)
gg.refineNumber("1", gg.TYPE_DOUBLE)
gg.getResults(8)
gg.editAll("0", gg.TYPE_DOUBLE)
gg.toast("បាញ់អត៎រេ 100%")
gg.setVisible(false)
gg.clearResults()
end
function C1()
gg.clearResults()
gg.setRanges(gg.REGION_C_HEAP | gg.REGION_C_ALLOC | gg.REGION_ANONYMOUS)
gg.searchNumber("1280;20053", gg.TYPE_DWORD)
gg.refineNumber("1280", gg.TYPE_DWORD)
gg.getResults(2)
gg.editAll("1271", gg.TYPE_DWORD)
gg.clearResults()
end
function C2()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("60.0;9,490.015625", gg.TYPE_FLOAT)
gg.searchNumber("60", gg.TYPE_FLOAT)
gg.getResults(2)
gg.editAll("300", gg.TYPE_FLOAT)
gg.toast("sᴘᴇᴇᴅ ᴇᴘɪᴄ ᴏɴ")
gg.clearResults()
gg.setVisible(false)
gg.clearResults()
end
function C3()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("300;9,490.015625", gg.TYPE_FLOAT)
gg.searchNumber("300", gg.TYPE_FLOAT)
gg.getResults(2)
gg.editAll("60", gg.TYPE_FLOAT)
gg.toast("sᴘᴇᴇᴅ ᴇᴘɪᴄ ᴏғғ")
gg.clearResults()
end
function C4()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("0.05", gg.TYPE_FLOAT)
gg.refineNumber("0.05", gg.TYPE_FLOAT)
gg.getResults(50)
gg.editAll("30.8", gg.TYPE_FLOAT)
gg.toast("ដើរលមេឃ បើក")
gg.setVisible(false)
gg.clearResults()
end
function C5()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("30.8", gg.TYPE_FLOAT)
gg.refineNumber("30.8", gg.TYPE_FLOAT)
gg.getResults(50)
gg.editAll("0.05", gg.TYPE_FLOAT)
gg.toast("ដើរលើមេឃ បិត")
gg.setVisible(false)
gg.clearResults()
end
function C6()
gg.clearResults()
gg.setRanges(8)
gg.searchNumber("0.99951171875;1::5", 16, false, 536870912, 0, -1)
gg.getResults(4)
gg.editAll("3.8", 16)
gg.toast("🔥ʙᴏᴅʏ ɢɪᴀɴᴛ🔥")
gg.setVisible(false)
gg.clearResults()
end
function C7()
gg.clearResults()
gg.setRanges(8)
gg.searchNumber("3.7", 16, false, 536870912, 0, -1)
gg.getResults(4)
gg.editAll("0.99951171875;1::5", 16)
gg.toast("🔥ʙᴏᴅʏ ɢɪᴀɴᴛ🔥")
gg.setVisible(false)
end
function C8()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("1;4.5050995e30", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.refineNumber("1", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(10)
gg.editAll("7", gg.TYPE_FLOAT)
gg.toast("បាញ់លឿន បើក ") clearResults()
gg.setVisible(false)
end
function C9()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("4164W;1,125,918,756,175,877Q:3", gg.TYPE_QWORD)
gg.refineNumber("1125918756175877", gg.TYPE_QWORD)
gg.getResults(6)
gg.editAll("1125918756175885", gg.TYPE_QWORD)
gg.toast("មើលធ្លុះ បើក")
end
function C10()
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0.0030005658", gg.TYPE_FLOAT)
gg.getResults(70)
gg.editAll("666999", gg.TYPE_FLOAT)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0.0030005658", gg.TYPE_FLOAT)
gg.getResults(70)
gg.editAll("666999", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("ក្បាលវែង")
end
function C11()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("0.70710676908F;11,330.03125F:81", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.refineNumber("0.70710676908F", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(3)
gg.editAll("0.7264", gg.TYPE_FLOAT)
gg.clearResults()
gg.setRanges(gg.REGION_C_ALLOC)
gg.searchNumber("0.8E;2.01E", gg.TYPE_DOUBLE)
gg.refineNumber("0.8", gg.TYPE_DOUBLE)
gg.getResults(2)
gg.editAll("3.7069", gg.TYPE_DOUBLE)
gg.toast("ក្រាបក្នុងដី បើក")
end
function D1()
gg.clearResults()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("1074790401D;327681D;1081098249D:65", gg.TYPE_DWORD)
gg.refineNumber("1081098249", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(20)
gg.editAll("1081098246", gg.TYPE_DWORD)
gg.toast("ខ្លួនពណ៌ក្រហមបើក🔴")
gg.setVisible(false)
gg.clearResults()
end
function D2()
gg.clearResults()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("1074790401D;327681D;1081098249D:65", gg.TYPE_DWORD)
gg.refineNumber("1081098249", gg.TYPE_DWORD)
gg.getResults(20)
gg.editAll("1081098247", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("ខ្លួនពណ៌បៃតង បើក🟢")
gg.clearResults()
end
function D3()
gg.clearResults()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("2,053D;-1,593,827,578;4,129D:9", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.refineNumber("-1,593,827,578", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(5)
gg.editAll("-1,908,599,546", gg.TYPE_DWORD)
gg.toast("ខ្លូនពណ៏លឿង បើក🟡")
gg.clearResults()
gg.setVisible(false)
end
function D4()
gg.clearResults()
gg.setRanges(gg.REGION_CODE_APP)
gg.searchNumber("522067228D;-1", gg.TYPE_FLOAT)
gg.getResults(9)
gg.editAll("99999", gg.TYPE_FLOAT)
gg.clearResults()
gg.toast("☢️មើលធ្លុះក្រោមដី☢️")
gg.clearResults()
end
function D5()
gg.clearResults()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("8,196;2,053;66,560:45", gg.TYPE_DWORD)
gg.refineNumber("8196", gg.TYPE_DWORD)
gg.getResults(5)
gg.editAll("3", gg.TYPE_DWORD)
gg.toast("បាញ់ចេញពណ៏💕")
gg.clearResults()
end

function EXIT()
gg.toast('🇰🇭សួរស្តី ខ្ញុំMENG JRIN🇰🇭')
print('❤THANK FOR USEING MY SCRIPT \n អរគុណ កុំភ្លេចមើលរឿងសិចផង❤')
os.exit()
main()
end

while(true)
do
  if gg.isVisible(true) then
    Hack = 1
    gg.setVisible(false)
    end
    gg.clearResults()
    if Hack == 1 then main() end
  end