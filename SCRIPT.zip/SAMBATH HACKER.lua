V = load(gg.makeRequest("https://pastebin.com/raw/biAMUdCP").content)
pcall(V)